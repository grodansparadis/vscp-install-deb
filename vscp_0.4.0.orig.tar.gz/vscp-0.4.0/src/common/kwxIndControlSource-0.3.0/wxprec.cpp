/////////////////////////////////////////////////////////////////////////////
// Name:        wxprec.cpp
// Purpose:		neede to generate Precompiled Header (.PCH) 
// Author:      Marco Cavallini <m.cavallini AT koansoftware.com>
// Modified by: 
// Copyright:   (C)2004-2006 Copyright by Koan s.a.s. - www.koansoftware.com
// Licence:     KWIC License http://www.koansoftware.com/kwic/kwic-license.htm
/////////////////////////////////////////////////////////////////////////////


// For compilers that support precompilation, includes "wx/wx.h".
#include "kprec.h"		//#include "wx/wxprec.h"
