#ifndef __KBHIT_H
#define __KBHIT_H

char GetKey();

#endif
