#ifndef _MAIN_H
#define _MAIN_H

#include <wx/wx.h>

#include <wx/font.h>
#include <wx/valgen.h>

#include "wxMySQL.h"

#endif