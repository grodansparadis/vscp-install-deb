This source was taken from the Microsoft Windows 2003 DDK.
If you want to compile this, use the build environments located in the DDK software.
However, you don't have to comile this, I have included the compiled sys file in the parent directory so that you do not have to.

--Miah