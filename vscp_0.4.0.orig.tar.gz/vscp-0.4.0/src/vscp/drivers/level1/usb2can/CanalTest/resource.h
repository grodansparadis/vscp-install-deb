//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by testDriver.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TIMER_READ                  101
#define IDD_TESTPIPEIF_DIALOG           102
#define IDD_TESTDRIVER_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_TRAY_STATE1                 170
#define IDC_TRAY_STATE0                 171
#define IDC_BUTTON_SEND_MSG             1000
#define IDC_EDIT_STATUS                 1001
#define IDC_COMBO1                      1002
#define IDC_COMBO_MSG_SELECT            1002
#define IDC_COMBO_ADAPTERS              1002
#define IDC_BUTTON_OPEN                 1003
#define IDC_CONECTION_STATE             1004
#define IDC_EDIT_MSGID                  1005
#define IDC_EDIT_DATABYTE0              1006
#define IDC_EDIT_DATABYTE1              1007
#define IDC_EDIT_DATABYTE2              1008
#define IDC_EDIT_DATABYTE3              1009
#define IDC_EDIT_DATABYTE4              1010
#define IDC_EDIT_DATABYTE5              1011
#define IDC_EDIT_DATABYTE6              1012
#define IDC_BUTTON_GET_VERSION          1013
#define IDC_BUTTON_GET_PROPERTIES       1014
#define IDC_BUTTON_OPEN2                1015
#define IDC_EDIT_OPTION                 1016
#define IDC_EDIT_BAUDRATE               1016
#define IDC_STATIC_MISC_LABEL           1017
#define IDC_STATIC_OPTION1_LABEL        1017
#define IDC_EDIT_DATABYTE7              1018
#define IDC_CHECK_EXTENDED              1019
#define IDC_CHECK_RTR                   1020
#define IDC_CHECK_ERROR                 1021
#define IDC_EDIT_SERIAL                 1021
#define IDC_EDIT_OPTION2                1022
#define IDC_STATIC_OPTION1_LABEL2       1022
#define IDC_STATIC_MISC_LABEL2          1023
#define IDC_STATIC_OPTION2_LABEL        1023
#define IDC_STATIC_OPTION1_LABEL3       1023
#define IDC_BUTTON_CLEAR_DATA           1024
#define IDC_BUTTON_PREV                 1025
#define IDC_BUTTON_PREV2                1026
#define IDC_BUTTON_CLEAR_STATUS         1026
#define IDC_BUTTON_SEND_BURTS           1027
#define IDC_EDIT1                       1028
#define IDC_STATIC_SEND_COUNT           1029
#define IDC_STATIC_RECEIVE_COUNT        1030
#define IDC_CHECK_TIMESTAMP             1031
#define IDC_CHECK_NOFETCH               1032
#define IDC_BUTTON_READFIRST            1033
#define IDC_EDIT_SELECTIVE_ID           1034
#define IDC_EDIT_SELECTIV_FLAGS         1035
#define IDC_BUTTON_BIG_BURST            1036
#define IDC_CHECK_QUEUE_REPLACE         1037
#define IDC_CHECK_BLOCKING_MODE         1038
#define IDC_CHECK_SECURE_MODE           1039
#define IDC_CHECK_LOCAL_SEND            1040
#define IDC_BUTTON_VIRTUAL_TEST         1041
#define IDC_BUTTON_GET_ADAPTERS         1042
#define IDC_CHECK_QUEUE_REPLACE2        1042
#define IDC_BUTTON_TRANSFER             1043
#define IDC_CHECK_QUEUE_REPLACE3        1043
#define IDC_CHECK_LOCAL_SEND2           1044
#define IDC_EDIT2                       1044

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1045
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
