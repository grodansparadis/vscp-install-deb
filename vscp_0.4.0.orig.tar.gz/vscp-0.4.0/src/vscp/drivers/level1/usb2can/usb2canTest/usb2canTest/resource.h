//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by usb2canTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_USB2CANTEST_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDI_ICON2                       130
#define IDI_ICON3                       131
#define IDI_ICON4                       132
#define IDR_VELIAVA1                    133
#define IDI_ICON5                       135
#define IDI_ICON6                       137
#define IDC_TRAY_STATE1                 170
#define IDC_TRAY_STATE0                 171
#define IDC_CHECK_ENABLE_STATUS         1001
#define IDC_CHECK_DISABLE_RETRANSMIT    1002
#define IDC_CHECK_SILENT                1003
#define IDC_CHECK_LOOPBACK              1004
#define IDC_EDIT_INIT_STRING            1005
#define IDC_BUTTON_OPEN                 1006
#define IDC_LIST_MESSGES                1008
#define IDC_EDIT_MSG_ID                 1009
#define IDC_CHECK_EXTENDED              1011
#define IDC_CHECK_RTR                   1012
#define IDC_BUTTON_CLEAR_DATA           1013
#define IDC_BUTTON_SEND_MSG             1014
#define IDC_BUTTON_SEND_BURST           1015
#define IDC_EDIT_BURST_CNT              1016
#define IDC_EDIT_DATA0                  1017
#define IDC_EDIT_DATA1                  1018
#define IDC_EDIT_DATA2                  1019
#define IDC_EDIT_DATA3                  1020
#define IDC_EDIT_DATA4                  1021
#define IDC_EDIT_DATA6                  1022
#define IDC_EDIT_DATA5                  1023
#define IDC_BUTTON_GET_STATUS           1029
#define IDC_BUTTON_GET_STATISTICS       1030
#define IDC_RADIO1_BUSOFF               1032
#define IDC_RADIO_BUSPASSIVE            1033
#define IDC_RADIO_BUSWARNING            1034
#define IDC_RADIO_BUSERRFREE            1035
#define IDC_STATIC_HARDWARE             1036
#define IDC_STATIC_FIRMWARE             1037
#define IDC_STATIC_CANAL                1038
#define IDC_STATIC_CANALDLL             1039
#define IDC_STATIC_RECEIVED_FRAMES      1040
#define IDC_STATIC_RECEIVED_DATA        1041
#define IDC_STATIC_TRANSMITED_FRAMES    1042
#define IDC_STATIC_TRANSMITED_DATA      1043
#define IDC_STATIC_OVERRUNS             1044
#define IDC_STATIC_BUS_WARNINGS         1045
#define IDC_STATIC_BUS_OFF              1046
#define IDC_STATIC_TX_ERR               1047
#define IDC_STATIC_RX_ERR               1048
#define IDC_STATIC_SEND                 1049
#define IDC_STATIC_RECEIVED             1050
#define IDC_EDIT_DATA7                  1051
#define IDC_STATIC_ICON                 1053
#define IDC_BUTTON1                     1054
#define IDC_STATIC_VENDOR               1060

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1065
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
